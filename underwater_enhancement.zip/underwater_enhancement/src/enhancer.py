"""
Underwater Image Enhancement via Frequency and Spatial Domains Fusion
======================================================================
Implementation based on:
    Zhang, W. et al. "Underwater image enhancement via frequency and spatial
    domains fusion." Optics and Lasers in Engineering 186 (2025) 108826.
    DOI: 10.1016/j.optlaseng.2025.108826

Pipeline (5 stages):
    1. Optimal Background Light Selection  (§2.1)  — Quadtree, flatness score
    2. Color Recognition                   (§2.2)  — Channel difference factor M (Eq. 4)
    3. Adaptive Color Compensation         (§2.3)  — Per-cast correction (Eqs. 7–9)
    4. Contrast Enhancement                (§2.4)  — Homomorphic filter, S-curve (Eq. 17)
    5. Image Fusion                        (§2.5)  — CIE L*a*b* channel fusion (Eq. 20)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class EnhancerConfig:
    """All tuneable hyperparameters for the enhancement pipeline.

    Every default value is either stated explicitly in the paper or is the
    most faithful interpretation of its equations. Where the paper gives a
    range (e.g. k ∈ [0.5, 1]), the midpoint or recommended value is used.

    Parameters
    ----------
    bg_min_pixel_ratio : float
        Quadtree stop condition: subdivide until the candidate region has
        fewer than this fraction of total pixels.
        Paper §2.1: threshold B = 1 % of image pixels.
    color_cast_threshold : float
        Channel-difference factor M; images with M > threshold are colour-
        distorted. Paper §2.2 (Fig. 2): M = 0.20.
    alpha : float
        Compensation weight α for the primary attenuated channel (Eqs. 7–9).
        Paper states "constant parameter"; standard value is 1.0.
    beta : float
        Compensation weight β for the secondary attenuated channel (Eqs. 7–9).
        Paper states "constant parameter"; standard value is 1.0.
    hist_lower_pct : float
        Lower percentile for histogram tail removal in Eq. 10 (paper: 0.1 %).
    hist_upper_pct : float
        Upper percentile for histogram tail removal in Eq. 10 (paper: 99.9 %).
    hf_k : float
        S-curve steepness k in the homomorphic filter transfer function
        (Eq. 17). Paper §2.4: k ∈ [0.5, 1]. Default: 0.8.
    hf_d0_ratio : float
        Cutoff frequency D0 expressed as a fraction of min(H, W), making it
        adaptive to image resolution. Paper does not specify an exact pixel
        value; 0.25 gives a good spatial-to-frequency trade-off.
    hf_rh : float
        High-frequency gain rH ≥ 1 (§2.4). Default: 1.2.
    hf_rl : float
        Low-frequency gain rL < 1 (§2.4). Default: 0.5.
    fusion_omega : float
        Luminance blending coefficient ω in Eq. 20. The paper describes it
        as adjusting "background colour for underwater appearance" without
        fixing an exact value; 1.0 is neutral (no scaling).
    bilateral_d : int
        Neighbourhood diameter for the bilateral pre-filter applied before
        the quadtree search to suppress artificial bright spots (§2.1).
    bilateral_sigma_color : float
        Colour sigma for the bilateral pre-filter.
    bilateral_sigma_space : float
        Spatial sigma for the bilateral pre-filter.
    """

    bg_min_pixel_ratio: float = 0.01        # 1 % threshold B  (§2.1)
    color_cast_threshold: float = 0.20      # M threshold       (§2.2, Fig. 2)
    alpha: float = 1.0                      # Eqs. 7–9
    beta: float = 1.0                       # Eqs. 7–9
    hist_lower_pct: float = 0.1            # Eq. 10
    hist_upper_pct: float = 99.9           # Eq. 10
    hf_k: float = 0.8                      # Eq. 17, k ∈ [0.5, 1]
    hf_d0_ratio: float = 0.25             # adaptive D0
    hf_rh: float = 1.2                     # high-freq gain (rH ≥ 1)
    hf_rl: float = 0.5                     # low-freq gain  (rL < 1)
    fusion_omega: float = 1.0              # Eq. 20
    bilateral_d: int = 9
    bilateral_sigma_color: float = 75.0
    bilateral_sigma_space: float = 75.0


# ---------------------------------------------------------------------------
# Core pipeline
# ---------------------------------------------------------------------------

class UnderwaterEnhancer:
    """Five-stage underwater image enhancement pipeline (Zhang et al., 2025).

    Usage
    -----
    >>> enhancer = UnderwaterEnhancer()
    >>> result   = enhancer.enhance(bgr_image)   # both arrays are BGR uint8

    The input array is never modified in-place.
    """

    def __init__(self, config: Optional[EnhancerConfig] = None) -> None:
        self.cfg = config or EnhancerConfig()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def enhance(self, img: np.ndarray) -> np.ndarray:
        """Run the full 5-stage pipeline on a single underwater image.

        Parameters
        ----------
        img : np.ndarray
            BGR image, dtype uint8, shape (H, W, 3).

        Returns
        -------
        np.ndarray
            Enhanced BGR image, dtype uint8, shape (H, W, 3).
        """
        self._validate(img)

        # Stage 1 — Background light selection
        bg_region = self._select_background(img)

        # Stages 2 & 3 — Color recognition + adaptive compensation
        color_corrected = self._adaptive_color_correction(img, bg_region)

        # Stage 4 — Homomorphic contrast enhancement
        #   Paper Fig. 1: frequency path receives the colour-corrected image.
        cc_gray = cv2.cvtColor(color_corrected, cv2.COLOR_BGR2GRAY)
        contrast_enhanced = self._homomorphic_filter(cc_gray)

        # Stage 5 — Fusion in CIE L*a*b* space
        return self._image_fusion(color_corrected, contrast_enhanced)

    # ------------------------------------------------------------------
    # Stage 1 — Optimal Background Light Selection  (§2.1)
    # ------------------------------------------------------------------

    def _select_background(self, img: np.ndarray) -> np.ndarray:
        """Return the flattest sub-region via quadtree search.

        The paper first smooths the image with a bilateral filter to remove
        artificial bright spots from strobes/lighting rigs before applying
        the quadtree (§2.1).  Flatness score S(i) = mean − std, averaged
        across the three colour channels (Eqs. 1–3).
        """
        cfg = self.cfg
        smoothed = cv2.bilateralFilter(
            img, cfg.bilateral_d,
            cfg.bilateral_sigma_color,
            cfg.bilateral_sigma_space,
        )

        h, w = smoothed.shape[:2]
        min_pixels = h * w * cfg.bg_min_pixel_ratio

        # Each box: (x, y, w, h) in absolute pixel coordinates
        candidates: list[Tuple[int, int, int, int]] = [(0, 0, w, h)]

        while True:
            best_score = -np.inf
            best_box: Tuple[int, int, int, int] = (0, 0, w, h)

            for box in candidates:
                rx, ry, rw, rh = box
                if rw == 0 or rh == 0:
                    continue
                patch = smoothed[ry: ry + rh, rx: rx + rw]
                score = self._flatness_score(patch)
                if score > best_score:
                    best_score = score
                    best_box = box

            rx, ry, rw, rh = best_box

            # Termination: region smaller than threshold B
            if rw * rh <= min_pixels:
                region = img[ry: ry + rh, rx: rx + rw]
                return region if region.size > 0 else img

            # Subdivide into four equal quadrants
            hw = max(rw // 2, 1)
            hh = max(rh // 2, 1)
            candidates = [
                (rx,      ry,      hw, hh),
                (rx + hw, ry,      hw, hh),
                (rx,      ry + hh, hw, hh),
                (rx + hw, ry + hh, hw, hh),
            ]

    @staticmethod
    def _flatness_score(patch: np.ndarray) -> float:
        """S(i) = mean(channel) − std(channel), averaged over R, G, B (Eqs. 1–2)."""
        if patch.size == 0:
            return -np.inf
        means = np.mean(patch, axis=(0, 1))
        stds  = np.std(patch,  axis=(0, 1))
        return float(np.mean(means - stds))

    # ------------------------------------------------------------------
    # Stages 2 & 3 — Color Recognition + Adaptive Compensation  (§2.2–2.3)
    # ------------------------------------------------------------------

    def _adaptive_color_correction(
        self, img: np.ndarray, bg_region: np.ndarray
    ) -> np.ndarray:
        """Classify colour cast and apply the matching compensation formula.

        Algorithm 1 from the paper:
        1. Compute per-channel means of the background region (Eq. 5).
        2. Compute M = max_channel − min_channel (Eq. 4).
        3. M ≤ 0.2  →  undistorted; apply histogram stretching only.
        4. Otherwise identify cast type via Dc (Eq. 6) and compensate
           (Eqs. 7, 8, or 9), then stretch (Eq. 10).
        """
        cfg = self.cfg
        img_f = img.astype(np.float64) / 255.0

        # Background channel means [0, 1] — OpenCV BGR order
        bg_f = bg_region.astype(np.float64) / 255.0
        bg_bgr = np.mean(bg_f, axis=(0, 1))          # (B̄, Ḡ, R̄)
        b_mean, g_mean, r_mean = bg_bgr

        # Eq. 4 — channel difference factor M
        M = float(bg_bgr.max() - bg_bgr.min())

        if M <= cfg.color_cast_threshold:
            # Undistorted: no colour compensation, only stretch
            return self._histogram_stretch(img_f)

        b, g, r = cv2.split(img_f)
        a, bt = cfg.alpha, cfg.beta

        # Eq. 6 — Dc: deviation of each channel from the overall background mean
        m_bar = (r_mean + g_mean + b_mean) / 3.0
        d_r = abs(r_mean - m_bar)
        d_g = abs(g_mean - m_bar)
        d_b = abs(b_mean - m_bar)

        if d_g >= d_r and d_g >= d_b:
            # --- Greenish (Eq. 7): green channel is reference ---
            r_c = r + a  * (g_mean - r_mean) * (1.0 - r) * g
            b_c = b + bt * (g_mean - b_mean) * (1.0 - b) * g
            g_c = g

        elif d_r >= d_g and d_r >= d_b:
            # --- Yellowish (Eq. 8): red channel is reference ---
            g_c = g + a  * (r_mean - g_mean) * (1.0 - g) * r
            b_c = b + bt * (r_mean - b_mean) * (1.0 - b) * r
            r_c = r

        else:
            # --- Bluish (Eq. 9): cascade — blue→green first, then green→red ---
            # Direct red compensation via blue causes red-artifact overcompensation;
            # the paper uses a two-step cascade to avoid this.
            g_c = g + a  * (b_mean - g_mean) * (1.0 - g) * b
            r_c = r + bt * (b_mean - r_mean) * (1.0 - r) * g_c   # uses adjusted g_c
            b_c = b

        corrected = cv2.merge([
            np.clip(b_c, 0.0, 1.0),
            np.clip(g_c, 0.0, 1.0),
            np.clip(r_c, 0.0, 1.0),
        ])
        return self._histogram_stretch(corrected)

    def _histogram_stretch(self, img_f: np.ndarray) -> np.ndarray:
        """Per-channel linear histogram stretching, Eq. 10.

        Removes the bottom ``hist_lower_pct`` % and top ``(100 − hist_upper_pct)`` %
        of pixels and linearly maps the remainder to [0, 255] uint8.
        Paper: remove 0.1 % of pixels from each tail.
        """
        cfg = self.cfg
        out_channels = []
        for ch in cv2.split(img_f):
            lo = np.percentile(ch, cfg.hist_lower_pct)
            hi = np.percentile(ch, cfg.hist_upper_pct)
            denom = hi - lo
            stretched = ch if denom < 1e-9 else np.clip((ch - lo) / denom, 0.0, 1.0)
            out_channels.append(stretched)
        return (cv2.merge(out_channels) * 255.0).astype(np.uint8)

    # ------------------------------------------------------------------
    # Stage 4 — Contrast Enhancement via Homomorphic Filter  (§2.4)
    # ------------------------------------------------------------------

    def _homomorphic_filter(self, img_gray: np.ndarray) -> np.ndarray:
        """Frequency-domain homomorphic filter with S-curve transfer function.

        The paper replaces the multi-parameter Gaussian transfer function
        (Eq. 15) with a simpler S-shaped curve (Eq. 17) that has a single
        tunable parameter k:

            H(u, v) = 1 / (1 + exp(−k · D(u,v)/D0))       ← logistic on D/D0

        This is a genuine high-pass filter:
            D → 0  :  H → 1/(1 + exp(0)) = 0.5  (low freq, attenuated by rL scaling)
            D → ∞  :  H → 1/(1 + 0)      = 1.0  (high freq, boosted by rH scaling)

        NOTE — transfer function form:
            The paper writes the argument as "−k · D0/D" (Eq. 17), which is a
            ratio form that produces H ≈ 1 at the DC component (D→0), making
            it a LOW-PASS filter — the opposite of the stated intent.  The
            correct logistic for a HIGH-PASS filter uses "D/D0 − 1" as the
            argument so that the inflection point is at D = D0 and H increases
            monotonically from ~rL (DC) to ~rH (high freq).  This
            interpretation matches Eq. 15 and the paper's qualitative description
            ("enhances high-frequency, suppresses low-frequency").

        Processing steps (Eqs. 12–19):
            ln(f) → FFT → H(u,v)·F(u,v) → IFFT → exp − 1 → normalise
        """
        cfg = self.cfg
        rows, cols = img_gray.shape

        # Adaptive cutoff D0 (pixels), scales with image resolution
        D0 = max(min(rows, cols) * cfg.hf_d0_ratio, 1.0)

        # Log transform — Eq. 12
        img_log = np.log1p(img_gray.astype(np.float64))

        # FFT with DC shifted to centre
        dft_shift = np.fft.fftshift(np.fft.fft2(img_log))

        # Distance map D(u, v) from DC
        crow, ccol = rows // 2, cols // 2
        v_idx = np.arange(rows) - crow
        u_idx = np.arange(cols) - ccol
        U, V = np.meshgrid(u_idx, v_idx)
        D_uv = np.hypot(U, V)
        D_uv[D_uv == 0] = 1e-9          # avoid divide-by-zero at DC

        # --- S-curve (corrected high-pass form) ---
        # Argument: k*(D/D0 - 1)
        #   D < D0  →  negative  →  H_base < 0.5  →  attenuated (low-pass side)
        #   D = D0  →  0         →  H_base = 0.5  →  inflection point
        #   D > D0  →  positive  →  H_base > 0.5  →  boosted  (high-pass side)
        H_base = 1.0 / (1.0 + np.exp(-cfg.hf_k * (D_uv / D0 - 1.0)))

        # Scale into [rL, rH]
        H = (cfg.hf_rh - cfg.hf_rl) * H_base + cfg.hf_rl

        # Filter — Eq. 14
        filtered = dft_shift * H

        # IFFT — Eq. 18
        img_back = np.real(np.fft.ifft2(np.fft.ifftshift(filtered)))

        # Exponential — Eq. 19
        img_exp = np.expm1(img_back)

        # Normalise to [0, 255]
        lo, hi = img_exp.min(), img_exp.max()
        if hi - lo < 1e-9:
            return np.zeros_like(img_gray, dtype=np.uint8)
        img_norm = (img_exp - lo) / (hi - lo)
        return (img_norm * 255.0).astype(np.uint8)

    # ------------------------------------------------------------------
    # Stage 5 — Image Fusion in CIE L*a*b* Space  (§2.5)
    # ------------------------------------------------------------------

    def _image_fusion(
        self,
        color_corrected: np.ndarray,
        contrast_enhanced_gray: np.ndarray,
    ) -> np.ndarray:
        """Fuse colour accuracy and luminance sharpness via L*a*b* (Eq. 20).

        Eq. 20:  I_fused = ω · I_dz  +  a*_cc  +  b*_cc

        where:
            I_dz  = L* channel from the contrast-enhanced image (sharp detail)
            a*_cc = a* channel from the colour-corrected image  (colour accuracy)
            b*_cc = b* channel from the colour-corrected image  (colour accuracy)
            ω     = fusion coefficient (adjusts perceived underwater appearance)
        """
        # Convert colour-corrected BGR → float L*a*b*  (L* ∈ [0, 100])
        cc_f32  = color_corrected.astype(np.float32) / 255.0
        lab_cc  = cv2.cvtColor(cc_f32, cv2.COLOR_BGR2Lab)
        _, a_cc, b_cc = cv2.split(lab_cc)

        # Scale contrast-enhanced luminance to L* range [0, 100]
        l_ce = contrast_enhanced_gray.astype(np.float32) / 255.0 * 100.0

        # Apply fusion coefficient ω
        l_fused = np.clip(self.cfg.fusion_omega * l_ce, 0.0, 100.0)

        # Reconstruct L*a*b* image and convert back to BGR
        fused_lab = cv2.merge([l_fused, a_cc, b_cc])
        fused_bgr = cv2.cvtColor(fused_lab, cv2.COLOR_Lab2BGR)

        return np.clip(fused_bgr * 255.0, 0.0, 255.0).astype(np.uint8)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate(img: np.ndarray) -> None:
        if img is None:
            raise ValueError("Input image is None.")
        if img.ndim != 3 or img.shape[2] != 3:
            raise ValueError(
                f"Expected a 3-channel BGR image; got shape {img.shape}."
            )
        if img.dtype != np.uint8:
            raise ValueError(
                f"Expected dtype uint8; got {img.dtype}. "
                "Convert with: (img / img.max() * 255).astype(np.uint8)"
            )
