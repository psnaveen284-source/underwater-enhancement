"""
run_enhancement.py
==================
Command-line tool for batch / single-image underwater enhancement.

Usage examples
--------------
# Single image:
    python scripts/run_enhancement.py --input path/to/image.png --output results/

# Batch folder:
    python scripts/run_enhancement.py --input path/to/folder/ --output results/

# Custom hyperparameters:
    python scripts/run_enhancement.py --input img.png --output results/ \\
        --hf-k 0.7 --fusion-omega 0.9 --color-threshold 0.18

# Side-by-side comparison grid:
    python scripts/run_enhancement.py --input folder/ --output results/ --grid
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from pathlib import Path
from typing import List

import cv2
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

# Ensure the src package is on the path when running from project root
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.enhancer import EnhancerConfig, UnderwaterEnhancer

matplotlib.use("Agg")   # Non-interactive backend for headless environments

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("run_enhancement")

SUPPORTED_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def collect_images(input_path: Path) -> List[Path]:
    """Return sorted list of image paths from a file or directory."""
    if input_path.is_file():
        return [input_path]
    if input_path.is_dir():
        paths = sorted(
            p for p in input_path.rglob("*")
            if p.suffix.lower() in SUPPORTED_EXT
        )
        return paths
    raise FileNotFoundError(f"Input path not found: {input_path}")


def read_image(path: Path) -> np.ndarray:
    """Read image; fall back to Pillow if OpenCV fails (e.g. CMYK JPEGs)."""
    img = cv2.imread(str(path))
    if img is not None:
        return img
    try:
        from PIL import Image
        pil = Image.open(path).convert("RGB")
        return cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)
    except Exception as exc:
        raise OSError(f"Cannot read image '{path}': {exc}") from exc


def save_comparison_grid(
    original: np.ndarray,
    enhanced: np.ndarray,
    save_path: Path,
    title: str = "",
) -> None:
    """Save a side-by-side comparison PNG."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    fig.suptitle(title, fontsize=12, y=1.01)

    for ax, img_bgr, label in zip(
        axes,
        [original, enhanced],
        ["Original (Degraded)", "Enhanced (Proposed Method)"],
    ):
        ax.imshow(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB))
        ax.set_title(label, fontsize=10)
        ax.axis("off")

    plt.tight_layout()
    fig.savefig(str(save_path), dpi=150, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Main processing loop
# ---------------------------------------------------------------------------

def process(args: argparse.Namespace) -> None:
    # Build config from CLI args
    cfg = EnhancerConfig(
        hf_k=args.hf_k,
        hf_d0_ratio=args.hf_d0_ratio,
        hf_rh=args.hf_rh,
        hf_rl=args.hf_rl,
        fusion_omega=args.fusion_omega,
        color_cast_threshold=args.color_threshold,
        alpha=args.alpha,
        beta=args.beta,
    )
    enhancer = UnderwaterEnhancer(cfg)

    input_path  = Path(args.input).expanduser().resolve()
    output_dir  = Path(args.output).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    image_paths = collect_images(input_path)
    if not image_paths:
        logger.error("No supported images found in '%s'.", input_path)
        sys.exit(1)

    logger.info("Found %d image(s). Processing...", len(image_paths))

    successes, failures = 0, 0
    t_start = time.perf_counter()

    for img_path in image_paths:
        try:
            original = read_image(img_path)
            t0 = time.perf_counter()
            enhanced = enhancer.enhance(original)
            elapsed = time.perf_counter() - t0

            stem = img_path.stem
            suffix = img_path.suffix.lower() or ".png"

            # Save enhanced image
            out_img = output_dir / f"enhanced_{stem}{suffix}"
            cv2.imwrite(str(out_img), enhanced)

            # Optionally save side-by-side grid
            if args.grid:
                out_grid = output_dir / f"grid_{stem}.png"
                save_comparison_grid(
                    original, enhanced, out_grid, title=img_path.name
                )

            logger.info(
                "  ✓  %-40s  →  %s  (%.2f s)",
                img_path.name,
                out_img.name,
                elapsed,
            )
            successes += 1

        except Exception as exc:
            logger.warning("  ✗  %s  —  %s", img_path.name, exc)
            failures += 1

    total = time.perf_counter() - t_start
    logger.info(
        "Done. %d succeeded, %d failed. Total time: %.1f s",
        successes, failures, total,
    )


# ---------------------------------------------------------------------------
# CLI argument parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Underwater Image Enhancement (Zhang et al., 2025)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--input",  "-i", required=True,
                   help="Path to a single image OR a directory of images.")
    p.add_argument("--output", "-o", required=True,
                   help="Output directory for enhanced images.")
    p.add_argument("--grid", action="store_true",
                   help="Also save side-by-side comparison grids.")

    # Homomorphic filter parameters
    hf = p.add_argument_group("Homomorphic Filter (Stage 4)")
    hf.add_argument("--hf-k",        type=float, default=0.8,
                    help="S-curve steepness k in Eq. 17 (paper: 0.5-1.0).")
    hf.add_argument("--hf-d0-ratio", type=float, default=0.25,
                    help="Cutoff D0 as fraction of min(H, W).")
    hf.add_argument("--hf-rh",       type=float, default=1.2,
                    help="High-frequency gain rH (≥ 1).")
    hf.add_argument("--hf-rl",       type=float, default=0.5,
                    help="Low-frequency gain rL (< 1).")

    # Colour correction parameters
    cc = p.add_argument_group("Colour Correction (Stages 2-3)")
    cc.add_argument("--color-threshold", type=float, default=0.20,
                    help="Channel-difference threshold M (Eq. 4).")
    cc.add_argument("--alpha",           type=float, default=1.0,
                    help="Primary channel compensation weight α (Eqs. 7-9).")
    cc.add_argument("--beta",            type=float, default=1.0,
                    help="Secondary channel compensation weight β (Eqs. 7-9).")

    # Fusion
    fus = p.add_argument_group("Fusion (Stage 5)")
    fus.add_argument("--fusion-omega", type=float, default=1.0,
                     help="Luminance blending coefficient ω (Eq. 20).")

    return p


if __name__ == "__main__":
    parser = build_parser()
    process(parser.parse_args())
