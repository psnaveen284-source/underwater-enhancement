"""
Unit tests for UnderwaterEnhancer.
Run with:  pytest tests/ -v
"""

from __future__ import annotations
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.enhancer import EnhancerConfig, UnderwaterEnhancer


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------

@pytest.fixture
def enhancer() -> UnderwaterEnhancer:
    return UnderwaterEnhancer()


def _greenish(h: int = 80, w: int = 100) -> np.ndarray:
    """Synthetic greenish image — G channel dominant."""
    img = np.zeros((h, w, 3), dtype=np.uint8)
    img[:, :, 1] = 180   # G
    img[:, :, 2] = 80    # R (attenuated)
    img[:, :, 0] = 60    # B (attenuated)
    noise = np.random.RandomState(42).randint(0, 20, img.shape, dtype=np.uint8)
    return np.clip(img.astype(np.int32) + noise, 0, 255).astype(np.uint8)


def _bluish(h: int = 80, w: int = 100) -> np.ndarray:
    """Synthetic bluish image — B channel dominant."""
    img = np.zeros((h, w, 3), dtype=np.uint8)
    img[:, :, 0] = 190   # B
    img[:, :, 1] = 90    # G
    img[:, :, 2] = 50    # R
    noise = np.random.RandomState(7).randint(0, 15, img.shape, dtype=np.uint8)
    return np.clip(img.astype(np.int32) + noise, 0, 255).astype(np.uint8)


def _yellowish(h: int = 80, w: int = 100) -> np.ndarray:
    """Synthetic yellowish image — R channel dominant."""
    img = np.zeros((h, w, 3), dtype=np.uint8)
    img[:, :, 2] = 190   # R
    img[:, :, 1] = 120   # G
    img[:, :, 0] = 40    # B (attenuated)
    noise = np.random.RandomState(3).randint(0, 15, img.shape, dtype=np.uint8)
    return np.clip(img.astype(np.int32) + noise, 0, 255).astype(np.uint8)


def _undistorted(h: int = 80, w: int = 100) -> np.ndarray:
    """Neutral image — channels roughly equal → M ≤ 0.2."""
    return np.random.RandomState(0).randint(100, 200, (h, w, 3), dtype=np.uint8)


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

class TestInputValidation:
    def test_none_raises(self, enhancer):
        with pytest.raises(ValueError, match="None"):
            enhancer.enhance(None)  # type: ignore

    def test_grayscale_raises(self, enhancer):
        with pytest.raises(ValueError, match="3-channel"):
            enhancer.enhance(np.zeros((50, 50), dtype=np.uint8))

    def test_four_channel_raises(self, enhancer):
        with pytest.raises(ValueError, match="3-channel"):
            enhancer.enhance(np.zeros((50, 50, 4), dtype=np.uint8))

    def test_float32_raises(self, enhancer):
        with pytest.raises(ValueError, match="uint8"):
            enhancer.enhance(np.zeros((50, 50, 3), dtype=np.float32))

    def test_float64_raises(self, enhancer):
        with pytest.raises(ValueError, match="uint8"):
            enhancer.enhance(np.zeros((50, 50, 3), dtype=np.float64))


# ---------------------------------------------------------------------------
# Output contract
# ---------------------------------------------------------------------------

class TestOutputContract:
    @pytest.mark.parametrize("img_fn", [_greenish, _bluish, _yellowish, _undistorted])
    def test_shape_preserved(self, enhancer, img_fn):
        img = img_fn()
        assert enhancer.enhance(img).shape == img.shape

    @pytest.mark.parametrize("img_fn", [_greenish, _bluish, _yellowish, _undistorted])
    def test_dtype_uint8(self, enhancer, img_fn):
        assert enhancer.enhance(img_fn()).dtype == np.uint8

    @pytest.mark.parametrize("img_fn", [_greenish, _bluish, _yellowish, _undistorted])
    def test_pixel_range(self, enhancer, img_fn):
        result = enhancer.enhance(img_fn())
        assert result.min() >= 0 and result.max() <= 255

    def test_input_not_modified(self, enhancer):
        img = _greenish()
        original = img.copy()
        enhancer.enhance(img)
        np.testing.assert_array_equal(img, original)


# ---------------------------------------------------------------------------
# Stage 1: Background selection
# ---------------------------------------------------------------------------

class TestBackgroundSelection:
    def test_returns_3d_array(self, enhancer):
        bg = enhancer._select_background(_greenish())
        assert bg.ndim == 3 and bg.shape[2] == 3

    def test_smaller_than_image(self, enhancer):
        img = _greenish(160, 200)
        bg = enhancer._select_background(img)
        assert bg.size <= img.size

    def test_single_pixel_image(self, enhancer):
        """Edge case: 1×1 image must not crash."""
        img = np.array([[[128, 100, 80]]], dtype=np.uint8)
        bg = enhancer._select_background(img)
        assert bg.ndim == 3

    def test_dtype_preserved(self, enhancer):
        bg = enhancer._select_background(_greenish())
        assert bg.dtype == np.uint8


# ---------------------------------------------------------------------------
# Stage 2-3: Colour correction
# ---------------------------------------------------------------------------

class TestColorCorrection:
    def test_greenish_boosts_red(self, enhancer):
        """After green-cast correction the red mean should increase."""
        img = _greenish()
        bg = enhancer._select_background(img)
        corrected = enhancer._adaptive_color_correction(img, bg)
        assert corrected[:, :, 2].mean() > img[:, :, 2].mean()

    def test_bluish_boosts_red_and_green(self, enhancer):
        img = _bluish()
        bg = enhancer._select_background(img)
        corrected = enhancer._adaptive_color_correction(img, bg)
        assert corrected[:, :, 2].mean() > img[:, :, 2].mean()

    def test_yellowish_boosts_green_and_blue(self, enhancer):
        img = _yellowish()
        bg = enhancer._select_background(img)
        corrected = enhancer._adaptive_color_correction(img, bg)
        assert corrected[:, :, 1].mean() > img[:, :, 1].mean()

    def test_undistorted_skips_compensation(self):
        """Images with M ≤ 0.2 should still produce a valid uint8 output."""
        e = UnderwaterEnhancer()
        img = _undistorted()
        bg = e._select_background(img)
        result = e._adaptive_color_correction(img, bg)
        assert result.dtype == np.uint8
        assert result.shape == img.shape

    def test_output_dtype(self, enhancer):
        img = _greenish()
        bg = enhancer._select_background(img)
        result = enhancer._adaptive_color_correction(img, bg)
        assert result.dtype == np.uint8


# ---------------------------------------------------------------------------
# Stage 4: Homomorphic filter
# ---------------------------------------------------------------------------

class TestHomomorphicFilter:
    def test_shape_preserved(self, enhancer):
        gray = np.random.randint(30, 200, (80, 100), dtype=np.uint8)
        out = enhancer._homomorphic_filter(gray)
        assert out.shape == gray.shape

    def test_dtype_uint8(self, enhancer):
        gray = np.random.randint(0, 256, (80, 100), dtype=np.uint8)
        assert enhancer._homomorphic_filter(gray).dtype == np.uint8

    def test_pixel_range(self, enhancer):
        gray = np.random.randint(0, 256, (80, 100), dtype=np.uint8)
        out = enhancer._homomorphic_filter(gray)
        assert out.min() >= 0 and out.max() <= 255

    def test_uniform_image_no_crash(self, enhancer):
        gray = np.full((60, 60), 128, dtype=np.uint8)
        out = enhancer._homomorphic_filter(gray)
        assert out.shape == gray.shape

    def test_transfer_function_is_high_pass(self):
        """Verify H increases monotonically with D — true high-pass behaviour."""
        cfg = EnhancerConfig(hf_k=0.8, hf_d0_ratio=0.25, hf_rh=1.2, hf_rl=0.5)
        rows, cols = 100, 120
        D0 = min(rows, cols) * cfg.hf_d0_ratio
        crow, ccol = rows // 2, cols // 2

        v = np.arange(rows) - crow
        u = np.arange(cols) - ccol
        U, V = np.meshgrid(u, v)
        D_uv = np.hypot(U, V)
        D_uv[D_uv == 0] = 1e-9

        H_base = 1.0 / (1.0 + np.exp(-cfg.hf_k * (D_uv / D0 - 1.0)))
        H = (cfg.hf_rh - cfg.hf_rl) * H_base + cfg.hf_rl

        H_dc     = float(H[crow - 2, ccol])
        H_cutoff = float(H[crow - int(D0), ccol])
        H_high   = float(H[crow, min(ccol + int(2 * D0), cols - 1)])

        assert H_dc < H_cutoff < H_high, (
            f"Filter is not high-pass: H(near-DC)={H_dc:.3f}, "
            f"H(D0)={H_cutoff:.3f}, H(2·D0)={H_high:.3f}"
        )

    def test_h_near_dc_close_to_rl(self):
        """Near DC, scaled H should be close to rL (low-freq suppression)."""
        cfg = EnhancerConfig(hf_k=2.0, hf_d0_ratio=0.25, hf_rh=1.2, hf_rl=0.5)
        rows, cols = 100, 100
        D0 = min(rows, cols) * cfg.hf_d0_ratio

        # D = 1 pixel from DC
        H_base_dc = 1.0 / (1.0 + np.exp(-cfg.hf_k * (1.0 / D0 - 1.0)))
        H_dc = (cfg.hf_rh - cfg.hf_rl) * H_base_dc + cfg.hf_rl
        assert H_dc < (cfg.hf_rh + cfg.hf_rl) / 2, \
            f"H near DC ({H_dc:.3f}) should be below mid-gain"


# ---------------------------------------------------------------------------
# Stage 5: Image fusion
# ---------------------------------------------------------------------------

class TestImageFusion:
    def test_output_shape(self, enhancer):
        cc   = _greenish()
        gray = np.random.randint(0, 256, cc.shape[:2], dtype=np.uint8)
        fused = enhancer._image_fusion(cc, gray)
        assert fused.shape == cc.shape

    def test_output_dtype(self, enhancer):
        cc   = _greenish()
        gray = np.random.randint(0, 256, cc.shape[:2], dtype=np.uint8)
        assert enhancer._image_fusion(cc, gray).dtype == np.uint8

    def test_pixel_range(self, enhancer):
        cc   = _greenish()
        gray = np.random.randint(0, 256, cc.shape[:2], dtype=np.uint8)
        out  = enhancer._image_fusion(cc, gray)
        assert out.min() >= 0 and out.max() <= 255

    def test_omega_zero_darkens_output(self):
        """ω = 0 sets L* channel to 0, result should be very dark."""
        e   = UnderwaterEnhancer(EnhancerConfig(fusion_omega=0.0))
        img = _greenish()
        result = e.enhance(img)
        assert result.mean() < 80


# ---------------------------------------------------------------------------
# End-to-end with custom config
# ---------------------------------------------------------------------------

class TestCustomConfig:
    @pytest.mark.parametrize("k", [0.5, 0.8, 1.0])
    def test_various_k_values(self, k):
        e = UnderwaterEnhancer(EnhancerConfig(hf_k=k))
        result = e.enhance(_greenish())
        assert result.dtype == np.uint8

    def test_high_rh_rl_contrast(self):
        e = UnderwaterEnhancer(EnhancerConfig(hf_rh=1.5, hf_rl=0.3))
        result = e.enhance(_bluish())
        assert result.shape == _bluish().shape

    def test_tight_histogram_stretch(self):
        e = UnderwaterEnhancer(EnhancerConfig(hist_lower_pct=1.0, hist_upper_pct=99.0))
        result = e.enhance(_yellowish())
        assert result.dtype == np.uint8

    def test_low_M_threshold_forces_compensation(self):
        """Setting threshold=0.0 means ALL images are treated as distorted."""
        e   = UnderwaterEnhancer(EnhancerConfig(color_cast_threshold=0.0))
        img = _undistorted()
        result = e.enhance(img)
        assert result.shape == img.shape
