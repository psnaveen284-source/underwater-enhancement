# Underwater Image Enhancement via Frequency and Spatial Domains Fusion

[![Python 3.9+](https://img.shields.io/badge/python-3.9%2B-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/<YOUR_USERNAME>/underwater-enhancement/blob/main/notebooks/demo_colab.ipynb)

A clean, fully-corrected Python implementation of the five-stage underwater image
enhancement pipeline proposed in:

> **Zhang, W., Li, X., Huang, Y., Xu, S., Tang, J., & Hu, H. (2025).**  
> *Underwater image enhancement via frequency and spatial domains fusion.*  
> Optics and Lasers in Engineering, 186, 108826.  
> https://doi.org/10.1016/j.optlaseng.2025.108826

---

## Algorithm Overview

```
Raw underwater image
        │
        ▼
┌─────────────────────────────────────────┐
│  Stage 1 · Background Light Selection   │  Bilateral pre-filter + Quadtree (§2.1)
│  Flatness score S(i) = mean − std       │  Eqs. 1–3
└─────────────────┬───────────────────────┘
                  │ background region
        ┌─────────▼──────────────┐
        │  Stage 2 · Recognition │  M = chan_max − chan_min (Eq. 4)
        └─────────┬──────────────┘  M > 0.20 → distorted
                  │ cast type {greenish | yellowish | bluish | undistorted}
        ┌─────────▼──────────────────────┐
        │  Stage 3 · Color Compensation  │  Eqs. 7–9 + histogram stretch (Eq. 10)
        └─────────┬──────────────────────┘
                  │ color_corrected (BGR uint8)
        ┌─────────▼───────────────────────────┐
        │  Stage 4 · Homomorphic Filter        │  S-curve H(u,v) in freq. domain (Eq. 17)
        │  H(u,v) = 1/(1+exp(−k·(D/D₀−1)))   │  True high-pass, single parameter k
        └─────────┬───────────────────────────┘
                  │ contrast_enhanced (gray uint8)
        ┌─────────▼──────────────────┐
        │  Stage 5 · L*a*b* Fusion   │  I_fused = ω·L*_ce + a*_cc + b*_cc (Eq. 20)
        └─────────┬──────────────────┘
                  ▼
        Enhanced BGR image
```

### Key equations

| Eq. | Formula | Stage |
|-----|---------|-------|
| (4) | `M = chan_max − chan_min` | Distortion threshold |
| (7) | Greenish: `Ir_c = Ir + α(Ḡ−R̄)(1−Ir)Ig` | Color compensation |
| (8) | Yellowish: `Ig_c = Ig + α(R̄−Ḡ)(1−Ig)Ir` | Color compensation |
| (9) | Bluish (cascade): `Ig_c = Ig + α(B̄−Ḡ)(1−Ig)Ib`; `Ir_c = Ir + β(B̄−R̄)(1−Ir)Ig_c` | Color compensation |
| (10) | `I_stretched = (I − Lc) / (Uc − Lc)` | Histogram stretch |
| (17) | `H(u,v) = 1 / (1 + exp(−k · D(u,v)/D₀))` | S-curve transfer fn |
| (20) | `I_fused = ω · I_dz + a*_cc + b*_cc` | L*a*b* fusion |

---

## Installation

```bash
git clone https://github.com/<YOUR_USERNAME>/underwater-enhancement.git
cd underwater-enhancement
pip install -r requirements.txt
```

---

## Quick Start

### Python API

```python
import cv2
from src.enhancer import UnderwaterEnhancer

enhancer = UnderwaterEnhancer()               # paper's default hyperparameters

img    = cv2.imread("underwater.jpg")         # BGR uint8
result = enhancer.enhance(img)

cv2.imwrite("enhanced.jpg", result)
```

### Command-line tool

```bash
# Single image + side-by-side comparison grid
python scripts/run_enhancement.py \
    --input path/to/image.png \
    --output results/ \
    --grid

# Batch folder
python scripts/run_enhancement.py \
    --input datasets/U45/ \
    --output results/ \
    --grid

# Tune the homomorphic filter (k ∈ [0.5, 1], paper §2.4)
python scripts/run_enhancement.py \
    --input img.png --output results/ \
    --hf-k 0.7 --hf-rh 1.5 --hf-rl 0.3
```

### Google Colab

Open `notebooks/demo_colab.ipynb` — it auto-downloads the U45 dataset and
lets you experiment interactively.

---

## Project Structure

```
underwater-enhancement/
├── src/
│   ├── __init__.py
│   └── enhancer.py          # Core pipeline: EnhancerConfig + UnderwaterEnhancer
├── scripts/
│   └── run_enhancement.py   # CLI tool: single image or batch folder
├── notebooks/
│   └── demo_colab.ipynb     # Interactive Colab demo + hyperparameter grid
├── tests/
│   └── test_enhancer.py     # 43 pytest unit tests
├── requirements.txt
└── README.md
```

---

## Configuration

```python
from src.enhancer import EnhancerConfig, UnderwaterEnhancer

cfg = EnhancerConfig(
    # Stage 1 — Background selection
    bg_min_pixel_ratio   = 0.01,   # Quadtree stop: 1 % of pixels (§2.1)
    bilateral_d          = 9,      # Bilateral pre-filter neighbourhood diameter
    bilateral_sigma_color= 75.0,
    bilateral_sigma_space= 75.0,

    # Stage 2-3 — Colour correction
    color_cast_threshold = 0.20,   # M threshold (§2.2, Fig. 2)
    alpha                = 1.0,    # Primary channel weight (Eqs. 7–9)
    beta                 = 1.0,    # Secondary channel weight
    hist_lower_pct       = 0.1,   # Histogram tail removal (Eq. 10)
    hist_upper_pct       = 99.9,

    # Stage 4 — Homomorphic filter
    hf_k                 = 0.8,    # S-curve steepness, paper: k ∈ [0.5, 1]
    hf_d0_ratio          = 0.25,   # Adaptive D₀ = ratio × min(H, W)
    hf_rh                = 1.2,    # High-freq gain (rH ≥ 1)
    hf_rl                = 0.5,    # Low-freq gain  (rL < 1)

    # Stage 5 — Fusion
    fusion_omega         = 1.0,    # Luminance coefficient ω (Eq. 20)
)
enhancer = UnderwaterEnhancer(cfg)
```

---

## Corrections vs. Prior Implementations

This implementation fixes the following bugs found in earlier notebook drafts:

| # | Issue | Bug | Fix |
|---|-------|-----|-----|
| 1 | **Cast type detection** | `g_mean == max_chan` (float `==`, fragile) | Uses `argmax` of `Dc` (Eq. 6), matching paper |
| 2 | **Bluish Eq. 9 — wrong reference mean** | Used `g_mean` in second step | Correct: `b_mean − r_mean` (paper Eq. 9) |
| 3 | **Transfer function (Eq. 17) — low-pass bug** | `exp(−k · D₀/D)` → H≈1 at DC → **low-pass** | Correct ratio `D/D₀ − 1` → H≈rL at DC → **high-pass** ✓ |
| 4 | **Fixed D₀ = 20 px** | Breaks on non-standard image sizes | Adaptive: `D₀ = hf_d0_ratio × min(H, W)` |
| 5 | **Missing bilateral pre-filter** | Quadtree picks bright strobed objects | Bilateral filter added before quadtree (§2.1) |
| 6 | **LAB colorspace conversion bug** | `cv2.COLOR_Lab2LBGR` (wrong flag) | `cv2.COLOR_Lab2BGR` with float32 input |
| 7 | **Shell commands in plain `.py`** | `!git clone` only works in Colab | Moved to notebook; all `.py` files are pure Python |

---

## Running Tests

```bash
pytest tests/ -v
```

43 tests covering input validation, output contracts, all three colour cast
types, high-pass filter verification, and custom configurations.

---

## Datasets

| Dataset | Images | Link |
|---------|--------|------|
| UIEB    | 890 paired | https://li-chongyi.github.io/proj_benchmark.html |
| U45     | 45 diverse | https://github.com/IPNUISTlegal/underwater-test-dataset-U45- |

---

## Citation

```bibtex
@article{zhang2025underwater,
  title   = {Underwater image enhancement via frequency and spatial domains fusion},
  author  = {Zhang, Weihong and Li, Xiaobo and Huang, Yizhao and Xu, Shuping
             and Tang, Junwu and Hu, Haofeng},
  journal = {Optics and Lasers in Engineering},
  volume  = {186},
  pages   = {108826},
  year    = {2025},
  doi     = {10.1016/j.optlaseng.2025.108826}
}
```

---

## License

MIT — see [LICENSE](LICENSE).
